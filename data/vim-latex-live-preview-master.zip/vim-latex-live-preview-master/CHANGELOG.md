Unreleased
----------

### Added

- [[`e33ee6c`](https://github.com/xuhdev/vim-latex-live-preview/commit/e33ee6c)] - Support multiple files project [#26](https://github.com/xuhdev/vim-latex-live-preview/pull/26)
- [[`bf5259b`](https://github.com/xuhdev/vim-latex-live-preview/commit/bf5259b)] - Support bibliography [#3](https://github.com/xuhdev/vim-latex-live-preview/pull/3)

### Fixed

- [[`cbf5a1d`](https://github.com/xuhdev/vim-latex-live-preview/commit/cbf5a1d)] - Support paths and filenames containing spaces [#35](https://github.com/xuhdev/vim-latex-live-preview/issues/35)
- [[`8cdc672`](https://github.com/xuhdev/vim-latex-live-preview/commit/8cdc672)] - Early exit on compilation failure [#25](https://github.com/xuhdev/vim-latex-live-preview/pull/25)

0.1.0 (Apr 16, 2013)
--------------------

- First release

<!--
vim: tw=0
-->

