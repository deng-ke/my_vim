#!/bin/sh

zip vim-latex-live-preview.zip ../plugin/*.vim ../doc/*.txt
